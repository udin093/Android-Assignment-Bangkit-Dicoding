package com.example.storyapp1.liststory.utils

import com.example.storyapp1.network.response.ListStoryItem

object DataDummy {
    fun generateDummyStoryResponse(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val quote = ListStoryItem(
                i.toString(),
                "createdAt + $i",
                "name $i",
                "description $i",
                0.0,
                "id $i",
                0.0,
            )
            items.add(quote)
        }
        return items
    }
}

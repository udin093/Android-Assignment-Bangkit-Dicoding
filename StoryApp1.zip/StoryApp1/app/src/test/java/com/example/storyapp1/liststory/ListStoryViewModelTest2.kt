package com.example.storyapp1.liststory

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.storyapp1.liststory.utils.DataDummy
import com.example.storyapp1.liststory.utils.LiveDataTestUtil.getOrAwaitValue
import com.example.storyapp1.liststory.utils.map
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.network.response.ListStoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.setMain
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(MockitoJUnitRunner::class)
class ListStoryViewModelTest2 {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var storyRepository: StoryRepository
    private lateinit var listStoryViewModel: ListStoryViewModel
    private lateinit var pref: UserSession
    private val dummyStory = DataDummy.generateDummyStoryResponse()

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(TestCoroutineDispatcher())
        pref = Mockito.mock(UserSession::class.java)
        listStoryViewModel = ListStoryViewModel(pref, storyRepository)
    }

    @Test
    fun `when Get ListStory Should Not Null and Return Success`() {
        val expectedStory = PagingData.from(dummyStory)
        val expectedLiveData = MutableLiveData<PagingData<ListStoryItem>>()

        val differ = AsyncPagingDataDiffer(
            diffCallback = ListStoryAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )

        expectedLiveData.value = expectedStory
        Mockito.`when`(storyRepository.getStory("token", 0)).thenReturn(expectedLiveData)

        val actualStory = listStoryViewModel.getStory("token", 0).getOrAwaitValue(2, TimeUnit.SECONDS)

        Mockito.verify(storyRepository).getStory("token", 0)
        Assert.assertNotNull(actualStory)
        Assert.assertTrue(actualStory is PagingData<ListStoryItem>)

        if (dummyStory.isNotEmpty() && differ.snapshot().isNotEmpty()) {
            Assert.assertEquals(dummyStory.map().first(), differ.snapshot().first())
        }

    }

    @Test
    fun `when Get ListStory with Empty Story Should Return Empty Data`() {
        val emptyStory = emptyList<ListStoryItem>()
        val expectedStory = PagingData.from(emptyStory)
        val expectedLiveData = MutableLiveData<PagingData<ListStoryItem>>()

        val differ = AsyncPagingDataDiffer(
            diffCallback = ListStoryAdapter.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main,
        )

        expectedLiveData.value = expectedStory
        Mockito.`when`(storyRepository.getStory("token", 0)).thenReturn(expectedLiveData)

        val actualStory = listStoryViewModel.getStory("token", 0).getOrAwaitValue(2, TimeUnit.SECONDS)

        Mockito.verify(storyRepository).getStory("token", 0)
        Assert.assertNotNull(actualStory)
        Assert.assertTrue(actualStory is PagingData<ListStoryItem>)

        Assert.assertEquals(0, differ.snapshot().size)

    }
}

val noopListUpdateCallback = object : ListUpdateCallback {
    override fun onInserted(position: Int, count: Int) {}
    override fun onRemoved(position: Int, count: Int) {}
    override fun onMoved(fromPosition: Int, toPosition: Int) {}
    override fun onChanged(position: Int, count: Int, payload: Any?) {}
}
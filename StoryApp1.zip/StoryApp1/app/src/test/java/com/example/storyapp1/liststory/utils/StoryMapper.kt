package com.example.storyapp1.liststory.utils

import com.example.storyapp1.network.response.ListStoryItem

fun List<ListStoryItem>.map() = map { story ->
    ListStoryItem(
        id = story.id,
        name = story.name,
        description = story.description,
        photoUrl = story.photoUrl,
        lat = story.lat,
        lon = story.lon,
    )
}
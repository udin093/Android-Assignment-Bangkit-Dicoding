package com.example.storyapp1.register

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyapp1.local.UserModel
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.network.ApiConfig
import com.example.storyapp1.network.response.RegisterResponse
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterViewModel(private val pref: UserSession) : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _msg = MutableLiveData<String>()
    val msg: LiveData<String> = _msg

    private val _isError = MutableLiveData<Boolean>()
    val isError: LiveData<Boolean> = _isError

    fun register(email: String, name: String, password: String) {
        _isLoading.value = true
        val param = JsonObject().apply {
            addProperty("email", email)
            addProperty("name", name)
            addProperty("password", password)
        }
        val client = ApiConfig.getApiService().register(email,name,password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null && responseBody.error == false) {
                        _msg.value = "Daftar Berhasil"
                        viewModelScope.launch {
                            pref.saveToken(
                                UserModel("", false, "")
                            )
                        }
                        _isError.value = false
                    } else {
                        _isError.value = true
                    }
                } else {
                    val errorResponse =
                        Gson().fromJson(response.errorBody()?.charStream(), RegisterResponse::class.java)
                    _msg.value = errorResponse?.message ?: "Error"
                    _isError.value = true
                    Log.e("RegisterViewModel", "onFailure: ${errorResponse?.message}")
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                _isLoading.value = false
                _msg.value = t.message.toString()
                _isError.value = true
                Log.e("RegisterViewModel", "onFailure: ${t.message.toString()}")
            }
        })
    }
}

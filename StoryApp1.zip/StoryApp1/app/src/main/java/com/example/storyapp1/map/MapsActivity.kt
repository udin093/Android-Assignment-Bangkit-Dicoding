package com.example.storyapp1.map

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.R
import com.example.storyapp1.ViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.storyapp1.databinding.ActivityMapsBinding
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.login.LoginActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "Settings")

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mapsViewModel: MapsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        supportActionBar?.hide()

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mapsViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserSession.getInstance(dataStore))
        )[MapsViewModel::class.java]

        mMap = googleMap

        mapsViewModel.getToken().observe(this) { user ->
            if (user.name != "") {
                title = user.name
                token = "Bearer " + user.token

                mapsViewModel.getMap(token, 1)

                mapsViewModel.map.observe(this) {
                    mMap.clear()

                    it.forEach { story ->
                        val lat = story.lat?.toDouble()
                        val lon = story.lon?.toDouble()

                        if (lat != null && lon != null) {
                            mMap.addMarker(
                                MarkerOptions().position(LatLng(lat, lon)).title(story.description)
                            )
                        }
                    }
                }
                val indonesia = LatLng(-2.096070, 113.212901)
                mMap.moveCamera(CameraUpdateFactory.newLatLng(indonesia))
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    companion object {
        private var token = "User Token"
    }
}
package com.example.storyapp1.liststory

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.storyapp1.local.UserModel
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.network.response.ListStoryItem

class ListStoryViewModel(private val pref: UserSession, private val storyRepository: StoryRepository) : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun getToken(): LiveData<UserModel> {
        return pref.getToken().asLiveData()
    }

    fun getStory(token: String, location: Int): LiveData<PagingData<ListStoryItem>> {
        return storyRepository.getStory(token, location).cachedIn(viewModelScope)
    }
}
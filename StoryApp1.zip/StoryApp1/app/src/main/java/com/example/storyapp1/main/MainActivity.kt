package com.example.storyapp1.main

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.ViewModelFactory
import com.example.storyapp1.addstory.AddStoryActivity
import com.example.storyapp1.databinding.ActivityMainBinding
import com.example.storyapp1.liststory.ListStoryActivity
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.login.LoginActivity
import com.example.storyapp1.map.MapsActivity
import kotlinx.coroutines.NonCancellable

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "Settings")

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel
    private lateinit var userSession: UserSession

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playAnimation()

        val dataStore: DataStore<Preferences> = this.dataStore
        userSession = UserSession.getInstance(dataStore)

        setViewModel()

        mainViewModel.getToken().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            } else {

                username = user.name

                binding.tvYourUsername.text = user.name
            }
        }

        binding.btGotoAddStory.setOnClickListener {
            val intent = Intent(this, AddStoryActivity::class.java)
            startActivity(intent)

        }

        binding.btGotoListStory.setOnClickListener {
            val intent = Intent(this, ListStoryActivity::class.java)
            startActivity(intent)

        }

        binding.btGotoMaps.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)

        }

        binding.tvLogout.setOnClickListener {
            AlertDialog.Builder(this@MainActivity).apply {
                setTitle("CONFIRMATION")
                setMessage("Logout of your account?")
                setPositiveButton("Yes") { _, _ ->
                    mainViewModel.logout()
                    finish()
                }
                setNegativeButton("No") { dialog, _ -> dialog.cancel() }
                create()
                show()
            }
        }


    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.tvSelamatDatang, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val namaAnimation =
            ObjectAnimator.ofFloat(binding.tvYourUsername, View.ALPHA, 1f).setDuration(500)
        val pilihMenuAnimation =
            ObjectAnimator.ofFloat(binding.tvSilahkanPilihMenu, View.ALPHA, 1f).setDuration(500)
        val menu1Animation =
            ObjectAnimator.ofFloat(binding.btGotoAddStory, View.ALPHA, 1f).setDuration(500)
        val menu2Animation =
            ObjectAnimator.ofFloat(binding.btGotoListStory, View.ALPHA, 1f).setDuration(500)

        val together = AnimatorSet().apply {
            playTogether(namaAnimation, pilihMenuAnimation)
        }

        AnimatorSet().apply {
            playSequentially(menu1Animation, menu2Animation, together)
            NonCancellable.start()
        }
    }


    private fun setViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserSession.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getToken().observe(this) { user ->
            if (user.name != "") {
                title = user.name
                token = "Bearer " + user.token
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    companion object {
        var username = ""
        private var token = "User Token"
    }
}

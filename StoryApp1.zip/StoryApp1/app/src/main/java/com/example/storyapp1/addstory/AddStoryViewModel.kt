package com.example.storyapp1.addstory

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.storyapp1.local.UserModel
import com.example.storyapp1.local.UserSession


class AddStoryViewModel(private val pref: UserSession) : ViewModel() {

    fun getUser(): LiveData<UserModel> {
        return pref.getToken().asLiveData()
    }
}


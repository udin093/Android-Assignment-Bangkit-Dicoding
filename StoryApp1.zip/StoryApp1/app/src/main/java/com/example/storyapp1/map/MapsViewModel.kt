package com.example.storyapp1.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.storyapp1.liststory.StoryRepository
import com.example.storyapp1.local.UserModel
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.network.response.ListStoryItem
import kotlinx.coroutines.launch

class MapsViewModel(private val pref: UserSession, private val storyRepository: StoryRepository) : ViewModel() {

    private val _map = MutableLiveData<List<ListStoryItem>>()
    var map: LiveData<List<ListStoryItem>> = _map

    fun getToken(): LiveData<UserModel> {
        return pref.getToken().asLiveData()
    }

    fun getMap(token: String, location: Int) {
        viewModelScope.launch {
            _map.postValue(storyRepository.getMap(token, location) as List<ListStoryItem>?)
        }
    }
}
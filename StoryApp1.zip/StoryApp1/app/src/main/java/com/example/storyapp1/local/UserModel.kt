package com.example.storyapp1.local

class  UserModel (
    val name: String,
    val isLogin: Boolean,
    val token: String,
)
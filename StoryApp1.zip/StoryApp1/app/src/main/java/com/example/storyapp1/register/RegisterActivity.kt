package com.example.storyapp1.register

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.ViewModelFactory
import com.example.storyapp1.databinding.ActivityRegisterBinding
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.login.LoginActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class RegisterActivity : AppCompatActivity(), View.OnClickListener {
    private val binding by lazy { ActivityRegisterBinding.inflate(layoutInflater) }
    private lateinit var registerViewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btRegister.setOnClickListener(this)
        binding.tvGotoLogin.setOnClickListener(this)

        setViewModel()


    }



    private fun setViewModel() {
        val pref = UserSession.getInstance(dataStore)
        registerViewModel = ViewModelProvider(
            this, ViewModelFactory(pref)
        )[RegisterViewModel::class.java]

        registerViewModel.isLoading.observe(this) {
            showLoading(it)
        }
        registerViewModel.isError.observe(this) {
            isError = it
        }
        registerViewModel.msg.observe(this) { msg ->
            AlertDialog.Builder(this@RegisterActivity).apply {
                setTitle("MyStoryApp1")
                setMessage(msg)
                setPositiveButton("OK") { _, _ ->
                    if (!isError) finish()
                }
                create()
                show()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progreeBarRegis.visibility =
            if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        var isError = false
    }

    override fun onClick(view: View) {
        when (view.id) {
            binding.btRegister.id -> {
                val name = binding.inputUsername.text.toString()
                val email = binding.inputEmail.text.toString()
                val password = binding.inputPassword.text.toString()
                when {
                    name.isEmpty() -> {
                        binding.layoutUsername.error = "Field masih kosong"
                    }
                    email.isEmpty() -> {
                        binding.layoutEmail.error = "Field masih kosong"
                    }
                    password.isEmpty() -> {
                        binding.layoutPassword.error = "Field masih kosong"
                    }
                    else -> {
                        registerViewModel.register(name, email, password)
                        registerViewModel.isError.observe(this) {
                            if (!it) {
                                AlertDialog.Builder(this@RegisterActivity).apply {
                                    setTitle("WELCOME!")
                                    setMessage("Register Success")
                                    setPositiveButton("OK") { _, _ ->
                                        val intent =
                                            Intent(context, LoginActivity::class.java)
                                        intent.flags =
                                            Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                        startActivity(intent)
                                        finish()
                                    }
                                    create()
                                    show()
                                }
                            }
                        }
                    }
                }
            }
            binding.tvGotoLogin.id -> {
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}

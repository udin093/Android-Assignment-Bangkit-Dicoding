package com.example.storyapp1.addstory

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.R
import com.example.storyapp1.ViewModelFactory
import com.example.storyapp1.addstory.camera.CameraLaunchActivity
import com.example.storyapp1.databinding.ActivityAddStoryBinding
import com.example.storyapp1.liststory.ListStoryActivity
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.main.MainActivity
import com.example.storyapp1.network.ApiConfig
import com.example.storyapp1.network.response.AddStoryResponse
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "Settings")

class AddStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddStoryBinding
    private lateinit var createViewModel: AddStoryViewModel

    companion object {
        const val CAMERA_X_RESULT = 200
    }

    private fun setupViewModel() {
        createViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserSession.getInstance(dataStore))
        )[AddStoryViewModel::class.java]
    }

    private fun getToken(): String {
        var token = "User Token"
        createViewModel.getUser().observe(this) { user ->
            if (user.token != "") {
                token = "Bearer " + user.token
            } else {
                Toast.makeText(this@AddStoryActivity, "Account Not Valid", Toast.LENGTH_SHORT).show()
            }
        }
        return token
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        title = resources.getString(R.string.newStory)

        setupViewModel()

        binding.btCamera.setOnClickListener { startCameraX() }
        binding.btGallery.setOnClickListener { startGallery() }
        binding.btUploadStory.setOnClickListener { uploadImage() }
    }

    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCameraX() {
        val intent = Intent(this, CameraLaunchActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private var getFile: File? = null
    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = it.data?.getSerializableExtra("picture") as File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            getFile = myFile
            val result = rotateFile(
                BitmapFactory.decodeFile(myFile.path),
                isBackCamera
            )

            binding.ivFotoUpload.setImageBitmap(result)
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri
            val myFile = uriToFile(selectedImg, this@AddStoryActivity)

            getFile = myFile

            binding.ivFotoUpload.setImageURI(selectedImg)
        }
    }

    private fun uploadImage() {
        if (getFile != null && binding.inputDeskripsi.text.toString().isNotEmpty()) {
            val file = getFile as File

            val description = binding.inputDeskripsi.text.toString().toRequestBody("text/plain".toMediaType())
            val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                "photo",
                file.name,
                requestImageFile
            )

            val service = ApiConfig.getApiService().postStories(
                getToken(),
                description,
                imageMultipart,
                0.0F,
                0.0F
            )
            service.enqueue(object : Callback<AddStoryResponse> {
                override fun onResponse(
                    call: Call<AddStoryResponse>,
                    response: Response<AddStoryResponse>
                ) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody != null && !responseBody.error!!) {
                            Toast.makeText(
                                this@AddStoryActivity,
                                responseBody.message,
                                Toast.LENGTH_SHORT
                            ).show()

                            val intent = Intent(applicationContext, ListStoryActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        Toast.makeText(
                            this@AddStoryActivity,
                            response.message(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<AddStoryResponse>, t: Throwable) {
                    Toast.makeText(
                        this@AddStoryActivity,
                        "Gagal instance Retrofit",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            Toast.makeText(
                this@AddStoryActivity,
                "Please fill the form correctly.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
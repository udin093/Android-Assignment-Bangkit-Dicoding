package com.example.storyapp1.liststory

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.ViewModelFactory
import com.example.storyapp1.databinding.ActivityListStoryBinding
import com.example.storyapp1.detailstory.DetailStoryActivity
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.login.LoginActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "Settings")

class ListStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListStoryBinding
    private lateinit var listStoryViewModel: ListStoryViewModel
    private lateinit var userSession: UserSession
    private lateinit var storyAdapter: ListStoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dataStore: DataStore<Preferences> = this.dataStore
        userSession = UserSession.getInstance(dataStore)

        listStoryViewModel = ViewModelProvider(
            this,
            ViewModelFactory(userSession)
        ).get(ListStoryViewModel::class.java)


        listStoryViewModel.loading.observe(this) { isLoading ->
            if (isLoading) {
                binding.progressBarStory.visibility = View.VISIBLE
                binding.rvReview.visibility = View.GONE
            } else {
                binding.progressBarStory.visibility = View.GONE
                binding.rvReview.visibility = View.VISIBLE
            }
        }

        listStoryViewModel.error.observe(this) { error ->
            if (error.isNotEmpty()) {
                binding.progressBarStory.visibility = View.GONE
                binding.rvReview.visibility = View.GONE
                binding.tvErrorData.text = error
                binding.tvErrorData.visibility = View.VISIBLE
            } else {
                binding.tvErrorData.visibility = View.GONE
            }
        }


        listStoryViewModel.getToken().observe(this) { user ->
            if (user.name.isNotEmpty()) {
                val token = "Bearer ${user.token}"
                getStories(token)
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    private fun getStories(token: String) {
        val listStoryAdapter = ListStoryAdapter { stories ->
            val intentToDetail = Intent(this@ListStoryActivity, DetailStoryActivity::class.java)
            intentToDetail.putExtra("USER", stories)
            startActivity(intentToDetail)
        }
        binding.rvReview.adapter = listStoryAdapter

        listStoryViewModel.getStory(token, 0).observe(this) { pagingData ->
            listStoryAdapter.submitData(lifecycle, pagingData)
        }
    }

}
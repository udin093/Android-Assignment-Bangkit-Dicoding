package com.example.storyapp1.detailstory

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.storyapp1.databinding.ActivityDetailStoryBinding
import com.example.storyapp1.network.response.ListStoryItem

class DetailStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detail = intent.getParcelableExtra<ListStoryItem>(USER)

        title =  detail?.name

        Glide.with(this).load(detail?.photoUrl).centerCrop().into(binding.ivDetailImgStory)
        binding.tvNameDetailStory.text = detail?.name
        binding.tvDeskDetailStory.text = detail?.description
    }

    companion object {
        const val USER = "USER"
    }

}
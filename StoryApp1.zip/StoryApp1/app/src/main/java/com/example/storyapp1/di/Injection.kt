package com.example.storyapp1.di

import com.example.storyapp1.liststory.StoryRepository
import com.example.storyapp1.network.ApiConfig

object Injection {
    fun provideRepository(): StoryRepository {
        val apiService = ApiConfig.getApiService()
        return StoryRepository(apiService)
    }
}
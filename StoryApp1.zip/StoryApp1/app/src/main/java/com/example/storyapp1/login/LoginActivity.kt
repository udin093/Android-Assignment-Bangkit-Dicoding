package com.example.storyapp1.login

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp1.R
import com.example.storyapp1.ViewModelFactory
import com.example.storyapp1.databinding.ActivityLoginBinding
import com.example.storyapp1.local.UserModel
import com.example.storyapp1.local.UserSession
import com.example.storyapp1.main.MainActivity
import com.example.storyapp1.register.RegisterActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class LoginActivity : AppCompatActivity() {
    private val binding by lazy { ActivityLoginBinding.inflate(layoutInflater) }
    private lateinit var user: UserModel
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.hide()

        binding.tvGotoRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.btLogin.setOnClickListener {
            val email = binding.inputEmail.text.toString()
            val password = binding.inputPassword.text.toString()
            when {
                email.isEmpty() -> {
                    binding.layoutEmail.error = "Username masih kosong"
                }

                password.isEmpty() -> {
                    binding.layoutPassword.error = "Password masih kosng"
                }

                else -> {
                    loginViewModel.authenticate(email, password)
                }
            }

        }

        setViewModel()

    }

    private fun setViewModel() {
        val pref = UserSession.getInstance(dataStore)

        loginViewModel = ViewModelProvider(this, ViewModelFactory(pref))[LoginViewModel::class.java]
        loginViewModel.getToken().observe(this) { user ->
            this.user = user
            MainActivity.username = user.name.toString().trim()
        }
        loginViewModel.isLoading.observe(this) {
            showLoading(it)
        }
        loginViewModel.msg.observe(this) {
            AlertDialog.Builder(this).apply {
                setTitle(getString(R.string.app_name))
                setMessage(it)
                setPositiveButton("OK") { _, _ ->
                }
                create()
                show()
            }
        }
        loginViewModel.isLogin.observe(this) {
            if (it) {
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBarLogin.visibility =
            if (isLoading) View.VISIBLE else View.GONE
    }

}
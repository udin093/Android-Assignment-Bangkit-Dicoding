package com.example.storyapp1.liststory

import androidx.lifecycle.LiveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.example.storyapp1.network.ApiService
import com.example.storyapp1.network.response.ListStoryItem
import com.example.storyapp1.paging.StoryPagingSource
import retrofit2.await


class StoryRepository(private val apiService: ApiService) {

    fun getStory(token: String, location: Int): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                StoryPagingSource(apiService, token, location)
            }
        ).liveData
    }

    suspend fun getMap(token: String, location: Int): List<ListStoryItem?> {
        val response = apiService.listStories(token, 1, 10, location)
        val data = response.await()

        return data.listStory ?: emptyList()
    }
}
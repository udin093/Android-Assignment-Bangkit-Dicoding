package com.example.myjurusancompose

class JurusanApp {
}
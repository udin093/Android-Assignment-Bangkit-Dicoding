package com.example.myjurusancompose.model

object DataJurusan {
}
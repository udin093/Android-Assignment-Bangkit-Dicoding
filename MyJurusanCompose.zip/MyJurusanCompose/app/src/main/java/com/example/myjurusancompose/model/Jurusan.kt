package com.example.myjurusancompose.model

data class Jurusan(
    val namaJurusan: String,
    val fakultas: String,
    val detailInfoJurusan: String,
    val photoJurusan: Int
)

package com.example.mygithubuser.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
     fun insert(user: FavoriteUser)

    @Delete
     fun delete(user: FavoriteUser)

    @Query("SELECT * FROM favorite_user")
    fun getAllFav() : Flow<List<FavoriteUser>>
}

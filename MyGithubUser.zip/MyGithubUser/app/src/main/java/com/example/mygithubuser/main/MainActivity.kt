package com.example.mygithubuser.main

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import com.example.mygithubuser.R
import com.example.mygithubuser.databinding.ActivityMainBinding
import com.example.mygithubuser.detail.DetailActivity
import com.example.mygithubuser.favorite.FavoriteActivity
import com.example.mygithubuser.setting.SettingActivity
import com.example.mygithubuser.setting.SettingPreference
import com.example.mygithubuser.setting.ViewModelSetting
import com.example.mygithubuser.setting.dataStore

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val userViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        userViewModel.loading.observe(this) { isLoading ->
            if (isLoading) {
                binding.progressBar.visibility = View.VISIBLE
                binding.rvReview.visibility = View.GONE
            } else {
                binding.progressBar.visibility = View.GONE
                binding.rvReview.visibility = View.VISIBLE
            }
        }

        userViewModel.error.observe(this) { error ->
            if (error.isNotEmpty()) {
                binding.progressBar.visibility = View.GONE
                binding.rvReview.visibility = View.GONE
                binding.tvErrorData.text = error
                binding.tvErrorData.visibility = View.VISIBLE
            } else {
                binding.tvErrorData.visibility = View.GONE
            }
        }

        userViewModel.users.observe(this) { users ->
            binding.rvReview.adapter = MainAdapter(users) { user ->
                val intent = Intent(this, DetailActivity::class.java)
                intent.putExtra(DetailActivity.Username, user.login)
                startActivity(intent)
            }
        }

        val pref = SettingPreference.getInstance(application.dataStore)
        val mainViewModel = ViewModelProvider(this, ViewModelSetting.ViewModelFactory(pref)).get(
            ViewModelSetting::class.java
        )
        mainViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu_top, menu)
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_key)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    userViewModel.findUsers(query)
                    searchView.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.setting -> {
                val intent = Intent(this, SettingActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.favorite -> {
                val intent = Intent(this, FavoriteActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

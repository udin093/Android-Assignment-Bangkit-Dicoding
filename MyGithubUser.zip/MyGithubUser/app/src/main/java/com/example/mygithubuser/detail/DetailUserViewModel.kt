package com.example.mygithubuser.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.mygithubuser.response.DetailUserGithubResponse
import com.example.mygithubuser.service.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.lifecycle.ViewModel

class DetailUserViewModel : ViewModel() {

    private val _user = MutableLiveData<DetailUserGithubResponse>()
    val user: LiveData<DetailUserGithubResponse> = _user

    private val _isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun getUserDetails(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object : Callback<DetailUserGithubResponse> {
            override fun onResponse(
                call: Call<DetailUserGithubResponse>,
                response: Response<DetailUserGithubResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _user.value = response.body()
                } else {
                    _error.value = "Gagal Mengambil Detail Data User"
                }
            }

            override fun onFailure(call: Call<DetailUserGithubResponse>, t: Throwable) {
                _isLoading.value = false
                _error.value = "Error: ${t.message}"
            }
        })
    }
}

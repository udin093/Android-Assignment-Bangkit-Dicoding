package com.example.mygithubuser.service

import com.example.mygithubuser.response.DetailUserGithubResponse
import com.example.mygithubuser.response.FollowersResponseItem
import com.example.mygithubuser.response.UserGithubResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("search/users")
    fun getUserGithub(
        @Query("q")q: String
    ) : Call<UserGithubResponse>

    @GET("users/{username}")
    fun getDetailUser(
        @Path("username") username: String
    ) : Call<DetailUserGithubResponse>

    @GET("users/{username}/followers")
    fun getUserDetailFollowers(
        @Path("username") username: String
    ) : Call<List<FollowersResponseItem>>

    @GET("users/{username}/following")
    fun getUserDetailFollowing(
        @Path("username") username: String
    ) : Call<List<FollowersResponseItem>>

}
package com.example.mygithubuser.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.mygithubuser.R
import com.example.mygithubuser.database.FavoriteUser
import com.example.mygithubuser.database.AndroidApplication
import com.example.mygithubuser.databinding.ActivityDetailBinding
import com.example.mygithubuser.favorite.FavoriteViewModel
import com.example.mygithubuser.followers.PagerAdapter
import com.example.mygithubuser.response.DetailUserGithubResponse
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val viewModel: DetailUserViewModel by viewModels()
    private lateinit var user: DetailUserGithubResponse


    private val favoriteViewModel: FavoriteViewModel by viewModels {
        FavoriteViewModel.FavoriteViewModelFactory(
            (application as AndroidApplication).database.FavoriteDao()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val username = intent.getStringExtra(Username)
        if (username != null) {
            viewModel.getUserDetails(username)
        }

        viewModel.loading.observe(this) { isLoading ->
            if (isLoading) {
                binding.progressBarDetail.visibility = View.VISIBLE
            } else {
                binding.progressBarDetail.visibility = View.GONE
            }
        }

        viewModel.error.observe(this) { error ->
            if (error.isNotEmpty()) {
                binding.progressBarDetail.visibility = View.GONE
                binding.tvErrorDetailUser.text = error
                binding.tvErrorDetailUser.visibility = View.VISIBLE
            } else {
                binding.tvErrorDetailUser.visibility = View.GONE
            }
        }

        viewModel.user.observe(this) { user ->
            this.user = user

            user.isFavorite = favoriteViewModel.allUsersFav.value?.contains(FavoriteUser(user.login.toString(), user.avatarUrl)) == true

            Glide.with(this)
                .load(user.avatarUrl)
                .into(binding.ivPhotoProfile)
            binding.tvDetailUsername.text = user.login
            binding.tvIdUser.text = user.id.toString()
            binding.tvFollowersUser.text = getString(R.string.jumlah_followers, user.followers)
            binding.tvFollowingUser.text = getString(R.string.jumlah_following, user.following)

            favoriteViewModel.allUsersFav.observe(this) { favorites ->
                val status = !favorites.contains(FavoriteUser(user.login.toString(), user.avatarUrl))
                if (status) {
                    binding.favoriteButton.setImageResource(R.drawable.baseline_favorite_border_24)
                } else {
                    binding.favoriteButton.setImageResource(R.drawable.baseline_favorite_24)
                }
            }
        }

        val detailPagerAdapter = PagerAdapter(this)
        val viewPager: ViewPager2 = binding.viewPagerFollow
        viewPager.adapter = detailPagerAdapter
        detailPagerAdapter.username = username.toString()
        val tabs: TabLayout = binding.tabsFollow
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = getString(TAB_TITLES[position])
        }.attach()

        binding.favoriteButton.setOnClickListener {
            val fUser = FavoriteUser(
                username = user.login.toString(),
                avatarUrl = user.avatarUrl
            )
            favoriteViewModel.allUsersFav.observe(this) {
                status = !it.contains(fUser)
            }

            if (status) {
                favoriteViewModel.insert(fUser)
                binding.favoriteButton.setImageResource(R.drawable.baseline_favorite_24)
                Toast.makeText(this, "${user.name} Berhasil Ditambahkan ke Favorit", Toast.LENGTH_SHORT).show()
            } else {
                favoriteViewModel.delete(fUser)
                binding.favoriteButton.setImageResource(R.drawable.baseline_favorite_border_24)
                Toast.makeText(this, "${user.name} Dihapus dari Favorit", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val Username = "login"

        private var status = true

    @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followersTab,
            R.string.followingTab
        )
    }
}



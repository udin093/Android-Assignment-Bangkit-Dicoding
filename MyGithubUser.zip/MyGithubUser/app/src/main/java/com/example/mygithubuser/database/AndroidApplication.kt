package com.example.mygithubuser.database

import android.app.Application

class AndroidApplication : Application() {
    val database: FavRoomDatabase by lazy { FavRoomDatabase.getDatabase(this) }
}


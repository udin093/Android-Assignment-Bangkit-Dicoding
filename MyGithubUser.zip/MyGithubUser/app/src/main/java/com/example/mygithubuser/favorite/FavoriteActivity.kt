package com.example.mygithubuser.favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mygithubuser.database.AndroidApplication
import com.example.mygithubuser.databinding.ActivityFavoriteBinding
import com.example.mygithubuser.detail.DetailActivity


class FavoriteActivity : AppCompatActivity() {
    private var binding: ActivityFavoriteBinding? = null

    private val favoriteViewModel: FavoriteViewModel by viewModels {
        FavoriteViewModel.FavoriteViewModelFactory(
            (application as AndroidApplication).database.FavoriteDao()
        )
    }
    private lateinit var adapter: UserFavoriteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        adapter = UserFavoriteAdapter { favoriteUser ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(DetailActivity.Username, favoriteUser.username)
            startActivity(intent)
        }

        binding?.rvUserFavorite?.layoutManager = LinearLayoutManager(this)
        binding?.rvUserFavorite?.adapter = adapter

        favoriteViewModel.allUsersFav.observe(this) { items ->
            items?.let { adapter.submitList(it) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }
}

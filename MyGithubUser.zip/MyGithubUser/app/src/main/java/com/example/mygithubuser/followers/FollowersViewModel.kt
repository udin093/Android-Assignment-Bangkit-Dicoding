package com.example.mygithubuser.followers

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mygithubuser.response.FollowersResponseItem
import com.example.mygithubuser.service.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersViewModel : ViewModel() {

    private val _users = MutableLiveData<List<FollowersResponseItem>>()
    val users: LiveData<List<FollowersResponseItem>> = _users

    private val _isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _isLoading

    fun getFollowersUser(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getUserDetailFollowers(username)
        client.enqueue(object : Callback<List<FollowersResponseItem>> {
            override fun onResponse(
                call: Call<List<FollowersResponseItem>>,
                response: Response<List<FollowersResponseItem>>
            ) {
                if (response.isSuccessful) {
                    val res = response.body() ?: emptyList()
                    _users.value = res
                } else {
                    _users.value = emptyList()
                }
                _isLoading.value = false
            }

            override fun onFailure(call: Call<List<FollowersResponseItem>>, t: Throwable) {
                _users.value = emptyList()
                _isLoading.value = false
            }
        })
    }
}


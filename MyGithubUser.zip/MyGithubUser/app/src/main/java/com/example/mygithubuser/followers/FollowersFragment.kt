package com.example.mygithubuser.followers

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.example.mygithubuser.databinding.FragmentFollowersBinding

class FollowersFragment : Fragment() {
    companion object {
        const val POSITION = "position"
        const val USERNAME = "username"
    }

    private var _binding: FragmentFollowersBinding? = null
    private val binding get() = _binding!!

    private lateinit var username: String
    private var position: Int = 0

    private val followersViewModel: FollowersViewModel by viewModels()
    private val followingViewModel: FollowingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            position = it.getInt(POSITION)
            username = it.getString(USERNAME).toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFollowersBinding.inflate(inflater, container, false)

        if (position == 1) {
            followersViewModel.loading.observe(viewLifecycleOwner) { isLoading ->
                binding.progressBarFollow.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
            followersViewModel.users.observe(viewLifecycleOwner) { followerList ->
                binding.rvFollow.adapter = FollowersAdapter(followerList)
            }

            followersViewModel.getFollowersUser(username)
        } else {
            followingViewModel.loading.observe(viewLifecycleOwner) { isLoading ->
                binding.progressBarFollow.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
            followingViewModel.users.observe(viewLifecycleOwner) { followingList ->
                binding.rvFollow.adapter = FollowersAdapter(followingList)
            }

            followingViewModel.getFollowingUser(username)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


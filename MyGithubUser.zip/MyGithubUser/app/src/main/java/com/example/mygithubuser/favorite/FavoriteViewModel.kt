package com.example.mygithubuser.favorite

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.mygithubuser.database.FavoriteDao
import com.example.mygithubuser.database.FavoriteUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FavoriteViewModel (private val favoriteDao: FavoriteDao): ViewModel() {
    val allUsersFav = favoriteDao.getAllFav().asLiveData()

    fun insert(user: FavoriteUser) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                favoriteDao.insert(user)
            }
        }
    }
    fun delete(user: FavoriteUser) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                favoriteDao.delete(user)
            }
        }
    }


    class FavoriteViewModelFactory(private val userDao: FavoriteDao) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(FavoriteViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return FavoriteViewModel(userDao) as T
            }
            throw IllegalArgumentException("Unknown ViewModel")
        }
    }
}


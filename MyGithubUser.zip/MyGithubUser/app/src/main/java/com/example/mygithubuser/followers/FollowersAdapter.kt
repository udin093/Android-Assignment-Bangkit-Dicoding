package com.example.mygithubuser.followers

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mygithubuser.databinding.ItemReviewBinding
import com.example.mygithubuser.response.FollowersResponseItem

class FollowersAdapter (private val followerList: List<FollowersResponseItem>) : RecyclerView.Adapter<FollowersAdapter.FollowerViewHolder>() {
    class FollowerViewHolder(private val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root) {
        val avatar: ImageView = binding.tvImg
        val username: TextView = binding.tvName
        val iduser: TextView = binding.tvIdAkun
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowerViewHolder {
        val binding = ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FollowerViewHolder, position: Int) {
        Glide.with(holder.itemView.context)
            .load(followerList[position].avatarUrl)
            .into(holder.avatar)
        val username = followerList[position].login
        holder.username.text = username
        val idAkun = followerList[position].id
        holder.iduser.text = idAkun.toString()
    }


    override fun getItemCount(): Int {
        return followerList.size
    }
}
package com.example.mygithubuser.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mygithubuser.response.ItemsItem
import com.example.mygithubuser.response.UserGithubResponse
import com.example.mygithubuser.service.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainViewModel : ViewModel() {

    private val _users = MutableLiveData<List<ItemsItem>>()
    val users: LiveData<List<ItemsItem>> = _users

    private val _isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    init {
        findUsers("arif")
    }

    fun findUsers(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getUserGithub(username)
        client.enqueue(object : Callback<UserGithubResponse> {
            override fun onResponse(
                call: Call<UserGithubResponse>,
                response: Response<UserGithubResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _users.value = responseBody.items as List<ItemsItem>?
                        _isLoading.value = false
                    }
                } else {
                    _isLoading.value = false
                    _users.value = listOf()
                }
            }

            override fun onFailure(call: Call<UserGithubResponse>, t: Throwable) {
                _users.value = listOf()
                _isLoading.value = false
                _error.value = t.message
            }
        })
    }
}

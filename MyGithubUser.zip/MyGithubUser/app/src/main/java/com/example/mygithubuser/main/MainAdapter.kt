package com.example.mygithubuser.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mygithubuser.databinding.ItemReviewBinding
import com.example.mygithubuser.response.ItemsItem

class MainAdapter(
    private val userList: List<ItemsItem>,
    private val onItemClickListener: (ItemsItem) -> Unit
) : RecyclerView.Adapter<MainAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = userList[position]
        holder.bind(user)
        holder.itemView.setOnClickListener { onItemClickListener(user) }
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    inner class ViewHolder(private val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(itemsItem: ItemsItem) {
            binding.tvName.text = itemsItem.login
            binding.tvIdAkun.text = itemsItem.id.toString()
            Glide.with(binding.root.context)
                .load(itemsItem.avatarUrl)
                .into(binding.tvImg)
        }
    }
}
